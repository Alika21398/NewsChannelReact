// export function callDate(){
//     const current = new Date();
//   const months=['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
//   const date= current.getDate();
//   const monthIndex=months[current.getMonth()];
//   const year=current.getFullYear();
//   const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
//   const day=days[current.getDay()];
//   return(
//     const formattedDate = `${day} ${monthIndex} ${date}, ${year}`;
//   )
// }